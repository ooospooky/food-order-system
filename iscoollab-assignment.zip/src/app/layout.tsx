import './globals.scss'
import type { Metadata } from 'next'
import React from 'react'
import { Inter } from 'next/font/google'
import Navbar from './components/navbar'
import { ReduxProvider } from '@/redux/features/provider'

const inter = Inter({ subsets: ['latin'] })

export const metadata:Metadata = {
  title: 'Food Order',
  description: 'Best Food Order System',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <ReduxProvider>
          <Navbar />
          {children}
        </ReduxProvider>
      </body>
    </html>
  )
}
